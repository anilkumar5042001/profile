import smtplib 
import random
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import datetime
import string

class CommonMethodsDAL:
    def Test(self):
    return "1"

   
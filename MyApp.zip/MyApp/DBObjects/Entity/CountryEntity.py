class CountryEntity(object):
    CountryName=""
    Countrycode=""
    CountryId=0
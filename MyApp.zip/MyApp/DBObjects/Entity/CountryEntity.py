class CountryEntity(object):
    CountryId=0
    Countrycode=""
    CountryName=""
    Flag=""
    
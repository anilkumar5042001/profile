class LanguageEntity(object):
    LanguageId=0
    ProfileId=""
    LanguageName=""
    LanguageLevel=""
class RoleEntity(object):
    ProfileId=0
    RoleId=0
    RoleName=""
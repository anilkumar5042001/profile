class WorkHistoryEntity(object):
    ProfileId=0
    WorkHistoryId=""
    CompanyName=""
    Role=""
    Description=""
    City=""
    Country=""
    StartMonth=""
    StartYear=""
    EndMonth=""
    EndYear=""
    CurrenltyWorking=""

class ProjectHighlightsEntity(object):
    ProjectHighlightsId=0
    WorkHistoryId=""
    ProjectHighlightsDescription=""

class ResponsibilitiesEntity(object):
    ResponsibilitiesId=0
    WorkHistoryId=""
    ResponsibilitiesDescription=""
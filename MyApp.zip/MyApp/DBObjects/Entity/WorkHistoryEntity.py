class WorkHistoryEntity(object):
    ProfileId=0
    WorkHistoryId=""
    CompanyName=""
    Role=""
    Description=""
    City=""
    Country=""
    StartMonth=""
    StartYear=""
    EndMonth=""
    EndYear=""
    CurrenltyWorking=""
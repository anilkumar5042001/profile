class WorkHistoryEntity(object):
    ProfileId=0
    WorkHistoryId=""
    CompanyName=""
    Role=""
    Description=""
    City=""
    Country=""
    StartDate=""
    EndDate=""
class PassionEntity(object):
    PassionId=0
    ProfileId=""
    PassionName="" 
    Description =""
class EducationEntity(object):
    EducationId=0
    ProfileId=""
    NameOfInstitution=""
    Degree=""
    StartYear=""
    EndYear=""
    EducationDescription=""
    City=""
    CountryId=""
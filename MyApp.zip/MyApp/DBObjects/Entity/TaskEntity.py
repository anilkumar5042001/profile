class TaskEntity(object):
    TaskId=0
    ProfileId=""
    TaskTitle=""
    Description=""
    DueDate=""
    AssignTo=""
    CreatedBy=""
    TaskStatus=""

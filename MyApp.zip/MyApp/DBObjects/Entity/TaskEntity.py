class TaskEntity(object):
    TaskId=0
    TaskCategoryId=""
    ProfileId=""
    TaskTitle=""
    Description=""
    DueDate=""
    FromDueDate=""
    ToDueDate=""
    AssignTo=""
    CreatedBy=""
    TaskStatus=""
    TaskDuration=""
    AssignToFullName=""
    CreatedByFullName=""
    NewCommentCount=0
    AssignToProfileImageName=""
    CreatedByProfileImageName=""

class ShareProfile (object):
    ShareProfileId=0
    ProfileId=""
    EmailId=""
    ProfileLink=""
    ExpiryDate=""
    SharedWith=""
    Message=""
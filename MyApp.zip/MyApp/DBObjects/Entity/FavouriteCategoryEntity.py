class FavouriteCategoryEntity(object):
    FavouriteCategoryId=0
    ProfileId=""
    FavouriteCategoryName="" 
class UserProfileEntity(object):
    ProfileId=0
    FirstName=""
    LastName=""
    EmailId=""
    PhoneNumber=""
    Education=""
    Designation=""
    City=""
    Country=""
    AboutMe=""
    Password=""
    CompanyDomain=""
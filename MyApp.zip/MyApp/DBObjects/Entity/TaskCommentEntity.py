class TaskCommentEntity(object):
    TaskCommentsId=0
    TaskId=""
    ProfileId=""
    Comment=""
    CommentedBy=""
    CommentOn=""
    FullName=""
    IsNew="0"
    CommentedByFullName=""
    CommentedToFullName=""
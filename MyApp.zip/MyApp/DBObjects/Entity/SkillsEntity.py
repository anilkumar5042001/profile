class SkillsEntity:
    SkillId=0
    ProfileId=""
    SkillCategoryId=""
    SkillName=""
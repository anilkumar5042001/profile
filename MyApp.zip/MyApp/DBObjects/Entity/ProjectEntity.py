class ProjectEntity(object):
    ProfileId=0
    ProjectId=0
    ProjectName=""
    ProjectDescription=""
    Role=""
    StartYear=""
    EndYear=""
    Responsibilities=""
    Awards=""
class InterestEntity(object):
    InterestId=0
    ProfileId=""
    InterestName=""
    
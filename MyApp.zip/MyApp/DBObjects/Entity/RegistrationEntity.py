class RegistrationEntity(object):
    RegistrationId=0
    EmailId=""
    Password=""
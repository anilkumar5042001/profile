class CertificationEntity(object):
    ProfileId=0
    CertificationId=""
    CertificationName=""
    Description=""
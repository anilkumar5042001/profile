class AwardsEntity(object):
    AwardId=0
    ProfileId=""
    AwardTitle=""
    AwardDescription=""
    FirstName=""
    LastName=""
    CompanyDomain=""
    CompanyName=""
    ShowInProfile=""
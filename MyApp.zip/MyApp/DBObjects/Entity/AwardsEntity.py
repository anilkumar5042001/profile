class AwardsEntity(object):
    AwardId=0
    ProfileId=""
    AwardTitle=""
    AwardDescription=""
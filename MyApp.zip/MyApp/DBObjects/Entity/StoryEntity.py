class StoryEntity(object):
    StoryId=0
    ProfileId=""
    StoryCategoryId=""
    StoryTitle=""
    Description=""
    Thumbnail=""
    IsPublished=""
    StoryDate=""
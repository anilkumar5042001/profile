class FavouriteEntity(object):
    FavouriteId=0
    ProfileId=""
    FavouriteCategoryId=""
    FavouriteName="" 
    FavouriteLink=""
    

class EventsEntity(object):
    EventId=0
    ProfileId=""
    EventCategoryId=""
    EventName=""
    Description=""
    StartDate=""
    EndDate=""
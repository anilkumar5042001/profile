class Event(object):

    EventId=0
    ProfileId=0
    EventCategoryId=0
    EventName=""
    Description=""
class CompanyEntity(object):
    CompanyId=0
    CompanyName=""
    DomainName=""
    Logo=""
    EmailId=""
    Password=""
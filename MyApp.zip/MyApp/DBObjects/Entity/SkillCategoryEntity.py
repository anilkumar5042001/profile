class SkillCategoryEntity(object):
    SkillCategoryId=0
    ProfileId=""
    SkillCategoryName=""
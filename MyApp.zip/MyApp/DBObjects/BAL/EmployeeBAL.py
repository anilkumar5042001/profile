import csv
from django.db import connection

class EmployeeBAL:
    def InsertEmployee(self,profileId):
        result = open(os.path.expanduser('media/Emp/cbc.csv')).read()
        with open(result) as csvfile:
            readCSV = csv.reader(csvfile, delimiter=',')
            for row in readCSV:
                cursor = connection.cursor()
                args = [row[0],row[1]]
                cursor.callproc('Interest_Insert',args)



class CommonMethods:
    def GetJson():
        return ""

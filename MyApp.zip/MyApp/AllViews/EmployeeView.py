from django.shortcuts import render
from django.http import Http404
from django.http import JsonResponse
from django.conf import settings
import json
from django.views.decorators.csrf import csrf_exempt
from django.core import serializers
from ..DBScripts.MySqlTable import MySqlTable
from ..DBScripts.ExecOrder import ExecOrder
from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response
from ..DBObjects.BAL import EmployeeBAL
from ..DBObjects.Entity import InterestEntity

#{"ProfileId": "1","InterestName":"Interest in c,c++"}
@csrf_exempt
@api_view(["POST"])
def EmployeeInsert(json_data):
        loaded_json = json.loads(json_data.body)
        strProfileId=loaded_json["ProfileId"]
        objEmployeeBAL=EmployeeBAL.EmployeeBAL()
        result=objEmployeeBAL.InsertEmployee(strProfileId)
        return JsonResponse("1",safe=False)


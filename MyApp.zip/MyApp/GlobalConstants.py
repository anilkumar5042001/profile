class GlobalConstants:
    SiteUrl="https://boring-rosalind-5ae0ce.netlify.com"
    WHVerificationUrl="verification"